import React from 'react';
import { render, screen } from '@testing-library/react';
import MyComponent from './components/PostGrid';

test('renders data from API', async () => {
  // Mocking axios to simulate API response
  jest.spyOn(global, 'fetch').mockResolvedValueOnce({
    json: jest.fn().mockResolvedValueOnce([
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' },
    ]),
  });

  render(<MyComponent />);

  // Wait for the component to render with data
  const items = await screen.findAllByRole('listitem');
  expect(items).toHaveLength(2);
});
