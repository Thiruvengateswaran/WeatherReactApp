// src/components/PostGrid.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './PostGrid.css';

const PostGrid = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/users');
        setPosts(response.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="post-grid">
      <h3>Employees Details</h3>
      {posts.map((post) => (
        <div key={post.id} className="post-item">
         <p>UserName:{post.username}<br></br>
             Email:{post.email}<br>
             </br>
             Company:{post.company.name}<br></br>
             
          </p>
        </div>
      ))}
    </div>
  );
};

export default PostGrid;
